# Figure 4 data

## dist_grid_pts.dat.gz

Values of distance (Mpc) at grid points for KDE values.

## incl_grid_pts.dat.gz

Values of inclination (deg) at grid points for KDE values.

## volumetric_marginal_posterior_pdf.dat.gz

2-D marginal posterior PDF values, using a volumetric prior, at the above grid
points.  These are the values of a kernel density estimate trained on samples
from above.

## em_dist_prior_marginal_posterior_pdf.dat.gz

2-D marginal posterior PDF values, using the EM distance prior, at the above
grid points.  These are the values of a kernel density estimate trained on
samples from above, reweighted to use the EM distance prior.

